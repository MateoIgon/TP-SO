# tp-2023-2c-9-30NoMeLevanto
Consigna: https://docs.google.com/document/d/1g6DEcbjilpX2XUBADuF6dPnrLv5lzoTZSVYCPgpHM_Q/edit
